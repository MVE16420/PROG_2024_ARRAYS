package holamundo;

public class Strat {
	
	public static void main(String[] args) { 
		
	int temperatura;
	temperatura = 25;
			
	char mes;
	mes='A';
		
	if (temperatura<0 && mes =='J') {
		
		System.out.println("chupi");
	}
	
	if (temperatura>30 && mes =='A') {
		
		System.out.println("mola");
	}
	
	if (temperatura<26 && mes=='A') {
		
		System.out.println("se esta bien");
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
