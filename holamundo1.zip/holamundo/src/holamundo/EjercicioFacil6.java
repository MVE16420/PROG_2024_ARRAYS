package holamundo;

public class EjercicioFacil6 {
	
	public static void main(String[] args) { 
	
	int numero1 = 1;
	int numero2 = 0;
    
	if (numero1>numero2) {
	    System.out.println("Orden:numero1,numero2");
	}
	
	else if (numero1<numero2) {
		System.out.println("Orden:numero2,numero1");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
}
