package holamundo;

public class EjercicioFacil8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	int nu1 = 237;
	
	  if (nu1 <10) {
		  System.out.println("numero de una cifra");
	  }
	  else if (nu1 > 9 && nu1 <100) {
		  System.out.println("numero de dos cifras");
	  }
	  else if (nu1 >99 && nu1 <1000) {
		  System.out.println("numero de tres cifras");
	  }
	  else if (nu1>999 && nu1 <10000) {
		  System.out.println("numero de cuatro cifras");
	  }
	
	
	
	
	
	
	
	
	
	}

}
